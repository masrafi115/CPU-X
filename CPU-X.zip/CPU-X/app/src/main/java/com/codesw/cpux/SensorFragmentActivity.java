package com.codesw.cpux;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import android.content.pm.PackageManager;
import android.hardware.SensorManager;

public class SensorFragmentActivity extends  Fragment  { 
	
	
	private String bt = "";
	private String wifi = "";
	private String gps = "";
	private String lw = "";
	private String microp = "";
	private String ameter = "";
	private String bmeter = "";
	private String comp = "";
	private String gyro = "";
	private String light = "";
	private String magnet = "";
	private String accel = "";
	private String ori = "";
	private String press = "";
	private String proxi = "";
	private String nfc = "";
	private String rotvect = "";
	private String temp = "";
	private String grav = "";
	private  SensorManager mSensorManager;
	private  PackageManager pm;
	
	private LinearLayout linear1;
	private CardView cardview1;
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.sensor_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
		cardview1 = (CardView) _view.findViewById(R.id.cardview1);
	}
	
	private void initializeLogic() {
		pm = getContext().getPackageManager();
		mSensorManager=(SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
		bt=SensorUtil.getBluetoothSupport(pm);
		
		wifi=SensorUtil.getWiFiSupport(pm);
		
		gps=SensorUtil.getGPSSupport(pm);
		
		lw=SensorUtil.getLiveWallpapersSupport(pm);
		
		microp=SensorUtil.getLiveMicrophoneSupport(pm);
		
		ameter=SensorUtil.getLiveAcceleratorMeterSupport(pm);
		
		bmeter=SensorUtil.getBarometerSupport(pm);
		
		comp=SensorUtil.getCompassSupport(pm);
		
		gyro=SensorUtil.getGyscopeSupport(pm);
		
		light=SensorUtil.getLightsSupport(pm);
		
		magnet=SensorUtil.getMagneticFieldSupport(mSensorManager);
		
		accel=SensorUtil.getLinearAccelerationSupport(mSensorManager);
		
		ori=SensorUtil.getOrientationSupport(mSensorManager);
		
		press=SensorUtil.getPressureSupport(mSensorManager);
		
		proxi=SensorUtil.getProximitySupport(pm);
		
		nfc=SensorUtil.getNFCSupport(pm);
		
		rotvect=SensorUtil.getRotationVectorSupport(mSensorManager);
		
		temp=SensorUtil.getTemparatureSupport(mSensorManager);
		
		grav=SensorUtil.getGravitySupport(mSensorManager);
		textview25.setText(bt);
		textview37.setText(wifi);
		textview39.setText(gps);
		textview41.setText(lw);
		textview43.setText(microp);
		textview45.setText(ameter);
		textview70.setText(bmeter);
		textview72.setText(comp);
		textview74.setText(gyro);
		textview76.setText(proxi);
		textview78.setText(temp);
		textview83.setText(grav);
		textview85.setText(ori);
		textview87.setText(press);
		textview89.setText(nfc);
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _sensor () {
	} public static class SensorUtil {
			
			public static String getBluetoothSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_BLUETOOTH)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getWiFiSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_WIFI)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getGPSSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LOCATION_GPS)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getLiveWallpapersSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LIVE_WALLPAPER)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getLiveMicrophoneSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_MICROPHONE)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getLiveAcceleratorMeterSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_SENSOR_ACCELEROMETER)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getBarometerSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_SENSOR_BAROMETER)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getCompassSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_SENSOR_COMPASS)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getGyscopeSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_SENSOR_GYROSCOPE)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getLightsSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_SENSOR_LIGHT)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getProximitySupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_SENSOR_PROXIMITY)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
		
			public static String getNFCSupport(android.content.pm.PackageManager pm) {
					if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_NFC)) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getMagneticFieldSupport(android.hardware.SensorManager sm) {
					if (sm.getDefaultSensor(android.hardware.Sensor.TYPE_MAGNETIC_FIELD) != null) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getLinearAccelerationSupport(android.hardware.SensorManager sm) {
					if (sm.getDefaultSensor(android.hardware.Sensor.TYPE_LINEAR_ACCELERATION) != null) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getOrientationSupport(android.hardware.SensorManager sm) {
					if (sm.getDefaultSensor(android.hardware.Sensor.TYPE_ORIENTATION) != null) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getPressureSupport(android.hardware.SensorManager sm) {
					if (sm.getDefaultSensor(android.hardware.Sensor.TYPE_PRESSURE) != null) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getRotationVectorSupport(android.hardware.SensorManager sm) {
					if (sm.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR) != null) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getTemparatureSupport(android.hardware.SensorManager sm) {
					if (sm.getDefaultSensor(android.hardware.Sensor.TYPE_TEMPERATURE) != null) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
		
			public static String getGravitySupport(android.hardware.SensorManager sm) {
					if (sm.getDefaultSensor(android.hardware.Sensor.TYPE_GRAVITY) != null) {
							return "Supported";
					} else {
							return "Not Supported";
					}
			}
	}
	
	
	
}