package com.codesw.cpux;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import java.util.Timer;
import java.util.TimerTask;
import java.text.DecimalFormat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class RamngpuFragmentActivity extends  Fragment  { 
	
	private Timer _timer = new Timer();
	
	private String ava = "";
	private double i2 = 0;
	private double n = 0;
	private double ud = 0;
	
	private LinearLayout linear1;
	private CardView cardview1;
	
	private TimerTask t;
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.ramngpu_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
		cardview1 = (CardView) _view.findViewById(R.id.cardview1);
	}
	
	private void initializeLogic() {
		/*
int n = 0;
	    try{
	      String[] arrayOfString = new java.io.RandomAccessFile("/proc/meminfo", "r").readLine().split(" kB")[0].split(" ");
	      n = Integer.parseInt(arrayOfString[(-1 + arrayOfString.length)]);
	    }catch (java.io.IOException localIOException) {
	    }
	
i2 = n / 1024;
textview25.setText(String.valueOf(i2));
t = new TimerTask() {
@Override
public void run() {
getActivity().runOnUiThread(new Runnable() {
@Override
public void run() {
ActivityManager localActivityManager = (ActivityManager)getContext().getSystemService("activity");
	    ActivityManager.MemoryInfo localMemoryInfo = new ActivityManager.MemoryInfo();
	    localActivityManager.getMemoryInfo(localMemoryInfo);
	    long av =  localMemoryInfo.availMem / 1024L / 1024L;
String ava = Long.valueOf(av).toString();
textview39.setText(ava);
double ud = i2 - Long.valueOf(av);
textview37.setText(String.valueOf((long)(ud)));
}
});
}
};
_timer.scheduleAtFixedRate(t, (int)(100), (int)(1000));
*/
		int n = 0;
			    try{
				      String[] arrayOfString = new java.io.RandomAccessFile("/proc/meminfo", "r").readLine().split(" kB")[0].split(" ");
				      n = Integer.parseInt(arrayOfString[(-1 + arrayOfString.length)]);
				    }catch (java.io.IOException localIOException) {
				    }
			
		i2 = n / 1024;
		textview25.setText(String.valueOf(i2).concat(" MB"));
		t = new TimerTask() {
			@Override
			public void run() {
				getActivity().getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {
						ActivityManager localActivityManager = (ActivityManager)getContext().getSystemService("activity");
							    ActivityManager.MemoryInfo localMemoryInfo = new ActivityManager.MemoryInfo();
							    localActivityManager.getMemoryInfo(localMemoryInfo);
							    long av =  localMemoryInfo.availMem / 1024L / 1024L;
						String ava = Long.valueOf(av).toString();
						textview39.setText(ava.concat(" MB"));
						double ud = i2 - Long.valueOf(av);
						textview37.setText(String.valueOf((long)(ud)).concat(" MB"));
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(100), (int)(1000));
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		t.cancel();
	}
	
}