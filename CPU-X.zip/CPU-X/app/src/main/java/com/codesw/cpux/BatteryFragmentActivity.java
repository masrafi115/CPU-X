package com.codesw.cpux;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import java.text.DecimalFormat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class BatteryFragmentActivity extends  Fragment  { 
	
	
	private String chargeType = "";
	private String healthStatus = "";
	private double level = 0;
	private String PERCENT = "";
	private String VOLT = "";
	private String TEMP = "";
	private String STAT = "";
	private String TECH = "";
	
	private LinearLayout linear1;
	private CardView cardview1;
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.battery_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
		cardview1 = (CardView) _view.findViewById(R.id.cardview1);
	}
	
	private void initializeLogic() {
		IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		            Intent batteryStatus = getContext().registerReceiver(null, ifilter);
		int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
		            boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
		            int chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
		            boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
		            boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;
		            boolean wirelessCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_WIRELESS;
		            String chargeType = "Not plugged";
		            if(usbCharge) {
			                chargeType = "USB Power";
			            } else if(acCharge) {
			                chargeType = "AC Power";
			            } else if(wirelessCharge) {
			                chargeType = "Wireless Power";
			            }
		
		int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
		String healthStatus = "" ;
		            if(health == BatteryManager.BATTERY_HEALTH_GOOD) {
			                healthStatus = "Good";
			            } else if(health == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
			                healthStatus = "Over Heat";
			            } else if(health == BatteryManager.BATTERY_HEALTH_DEAD) {
			                healthStatus = "Dead";
			            } else if(health == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {
			                healthStatus = "Over Voltage";
			            } else if(health == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE) {
			                healthStatus = "Unspecified failure";
			            } else if(health == BatteryManager.BATTERY_HEALTH_COLD) {
			                healthStatus = "Cold";
			            } else {
			                healthStatus = "UNKNOWN";
			            }
		String TECH = batteryStatus.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
		String STAT = Integer.valueOf(batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)).toString();
		float temp = ((float) batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0) / 10);
		String TEMP = Float.valueOf(temp).toString();
		String VOLT = Integer.valueOf(batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)).toString();
		int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
		int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
		String PERCENT = Boolean.valueOf(batteryStatus.getBooleanExtra(BatteryManager.EXTRA_PRESENT, false)).toString();
		textview41.setText(chargeType);
		if (textview41.getText().toString().equals("Not plugged")) {
			textview43.setText("Not plugged");
		}
		textview47.setText(healthStatus);
		textview37.setText(TECH);
		textview39.setText(TEMP.concat("°C"));
		textview45.setText(String.valueOf(Double.parseDouble(VOLT) / 1000).concat(" V"));
		textview25.setText(String.valueOf((long)(level)).concat("%"));
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	
}