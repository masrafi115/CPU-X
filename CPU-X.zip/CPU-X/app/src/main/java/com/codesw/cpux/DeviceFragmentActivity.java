package com.codesw.cpux;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class DeviceFragmentActivity extends  Fragment  { 
	
	
	private String model = "";
	private String manufacturer = "";
	private String name = "";
	private String patch = "";
	private String code_name = "";
	private String ver_code = "";
	private String platform = "";
	private String mainboard = "";
	private String bootldr = "";
	private String disp = "";
	private String osName = "";
	
	private LinearLayout linear1;
	private CardView cardview1;
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.device_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
		cardview1 = (CardView) _view.findViewById(R.id.cardview1);
	}
	
	private void initializeLogic() {
		String patch = Build.VERSION.SECURITY_PATCH;
		String code_name = Build.VERSION.RELEASE;
		String ver_code = Build.VERSION.SDK;
		String manufacturer = Build.MANUFACTURER;
		String model = Build.MODEL;
		String bootldr = Build.BOOTLOADER;
		String name = Build.DEVICE;
		String platform = Build.HARDWARE;
		String mainboard = Build.BOARD;
		osName = AndroidOSName();
		WindowManager windowManager = (WindowManager)getContext().getSystemService(Context.WINDOW_SERVICE);
		            Display display = windowManager.getDefaultDisplay();
		textview25.setText(model);
		textview37.setText(manufacturer);
		textview39.setText(name);
		textview41.setText(bootldr);
		textview49.setText(patch);
		textview47.setText(osName.concat(" v").concat(code_name));
		textview51.setText(ver_code);
		textview43.setText(platform.concat(" / ".concat(mainboard)));
		textview45.setText(String.valueOf((long)(SketchwareUtil.getDisplayWidthPixels(getContext()))).concat("X".concat(String.valueOf((long)(SketchwareUtil.getDisplayHeightPixels(getContext()))))));
		String disp = Float.valueOf(display.getRefreshRate()).toString();
		textview53.setText(disp);
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _getAndroidVersionName () {
	} public String AndroidOSName() {
		    String os = Build.VERSION.SDK;
		    System.out.println("here is my os" + " " + os);
		    if (os.equals("23")) {
			        return "Marshmallow";
			    } else if (os.equals("21")) {
			        return "Lollipop";
			    } else if (os.equals("22")) {
			        return "LOLLIPOP_MR1";
			    } else if (os.equals("20")) {
			        return "KitKat";
			    } else if (os.equals("19")) {
			        return "KitKat";
			    } else if (os.equals("18")) {
			        return "Jelly Bean";
			    } else if (os.equals("17")) {
			
			        return "Jelly Bean";
			    } else if (os.equals("16")) {
			        return "Jelly Bean";
			    } else if (os.equals("15")) {
			        return "Ice Cream Sandwich";
			    } else if (os.equals("14")) {
			        return "Ice Cream Sandwich";
			    } else if (os.equals("13")) {
			        return "Honeycomb";
			    } else if (os.equals("12")) {
			        return "Honeycomb";
			    } else if (os.equals("11")) {
			        return "Honeycomb";
			    } else if (os.equals("10")) {
			        return "Gingerbread";
			    } else if (os.equals("9")) {
			        return "Froyo";
			    } else if (os.equals("8")) {
			        return "Froyo";
			    } else {
			        return "Not Found";
			    }
		
	}
	
	
	
}