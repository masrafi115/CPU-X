package com.codesw.cpux;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import java.text.DecimalFormat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class CpuFragmentActivity extends  Fragment  { 
	
	
	private double cpu_min = 0;
	private double cpu_max = 0;
	
	private ArrayList<String> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private CardView cardview1;
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.cpu_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
		cardview1 = (CardView) _view.findViewById(R.id.cardview1);
	}
	
	private void initializeLogic() {
		if (new java.io.File("/proc/cpuinfo").exists()) {
				        try {
					            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(new java.io.File("/proc/cpuinfo")));
					            String aLine;
					            while ((aLine = br.readLine()) != null) {
										//aLine = aLine.replaceAll("\t","");
										aLine = aLine.replaceAll(":","");
						                String[] data = aLine.split ("\t");
										list.addAll(Arrays.asList(data));
					list.removeAll(Arrays.asList("", null));
						            }
					            if (br != null) {
						                br.close();
						            }
					        } catch (java.io.IOException e) {
					            e.printStackTrace();
					        } 
				    }
		int i = GetNumberOfCores();
		textview39.setText(Integer.valueOf(i).toString());
		cpu_min = getCpuMinFreq();
		cpu_max = getCpuMaxFreq();
		textview25.setText(list.get((int)(list.indexOf("Hardware") + 1)));
		textview37.setText(list.get((int)(list.indexOf("model name") + 1)));
		textview43.setText(list.get((int)(list.indexOf("Features") + 1)));
		textview49.setText(list.get((int)(list.indexOf("CPU implementer") + 1)));
		textview51.setText(list.get((int)(list.indexOf("CPU part") + 1)));
		textview53.setText(list.get((int)(list.indexOf("CPU revision") + 1)));
		textview55.setText(list.get((int)(list.indexOf("CPU variant") + 1)));
		textview41.setText(String.valueOf(cpu_min / 1000).concat("MHz -  ").concat(String.valueOf(cpu_max / 1000000).concat(" GHz")));
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _getCpuMaxFreq () {
	} public static long getCpuMaxFreq() {
		        long result = 0L;
		        try {
			            String line;
			            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"));
			            if ((line = br.readLine()) != null) {
				                result = Long.parseLong(line);
				            }
			            br.close();
			        } catch (java.io.IOException e) {
			            e.printStackTrace();
			        }
		        return result;
	}
	
	
	public void _getCpuMinFreq () {
	} public static long getCpuMinFreq() {
		        long result = 0L;
		        try {
			            String line;
			            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq"));
			            if ((line = br.readLine()) != null) {
				                result = Long.parseLong(line);
				            }
			            br.close();
			        } catch (java.io.IOException e) {
			            e.printStackTrace();
			        }
		        return result;
	}
	
	
	public void _getNumberOfCore () {
	} public static int GetNumberOfCores() {
				return (new java.io.File("/sys/devices/system/cpu/"))
						.listFiles(new java.io.FileFilter() {
								@Override
								public boolean accept(java.io.File f) {
										return Pattern.matches("cpu[0-9]+", f.getName());
								}
						}).length;
	}
	
	
	
}